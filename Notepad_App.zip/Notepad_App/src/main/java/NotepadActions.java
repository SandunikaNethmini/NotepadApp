import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class NotepadActions implements ActionListener {

    private NotepadUI ui;

    public NotepadActions(NotepadUI ui) {
        this.ui = ui;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        try {
            // File menu
            if (source == ui.newItem) {
                doNew();
            } else if (source == ui.openItem) {
                doOpen();
            } else if (source == ui.saveItem) {
                doSave();
            } else if (source == ui.exitItem) {
                doExit();
            }

            // Edit menu
            else if (source == ui.cutItem) {
                ui.textArea.cut();
            } else if (source == ui.copyItem) {
                ui.textArea.copy();
            } else if (source == ui.pasteItem) {
                ui.textArea.paste();
            }

            // Format menu
            else if (source == ui.fontItem) {
                Font chosen = NotepadUI.FontChooserDialog.showDialog(ui, ui.textArea.getFont());
                if (chosen != null) ui.textArea.setFont(chosen);
            } else if (source == ui.colorItem) {
                Color color = JColorChooser.showDialog(ui, "Choose Text Color", ui.textArea.getForeground());
                if (color != null) ui.textArea.setForeground(color);
            }

            // Help menu
            else if (source == ui.aboutItem) {
                JOptionPane.showMessageDialog(ui,
                        "Simple Notepad\nName: YOUR_NAME_HERE\nID: YOUR_ID_HERE",
                        "About",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            showError("An error occurred: " + ex.getMessage());
        }
    }

    private void doNew() {
        ui.textArea.setText("");
        ui.currentFile = null;
        ui.setTitle("SimpleNotepad - Untitled");
    }

    private void doOpen() {
        JFileChooser chooser = new JFileChooser();
        int ret = chooser.showOpenDialog(ui);
        if (ret == JFileChooser.APPROVE_OPTION) {
            File f = chooser.getSelectedFile();
            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line).append("\n");
                }
                ui.textArea.setText(sb.toString());
                ui.currentFile = f;
                ui.setTitle("SimpleNotepad - " + f.getName());
            } catch (IOException ex) {
                showError("Failed to open file: " + ex.getMessage());
            }
        }
    }

    private void doSave() {
        if (ui.currentFile == null) {
            JFileChooser chooser = new JFileChooser();
            int ret = chooser.showSaveDialog(ui);
            if (ret != JFileChooser.APPROVE_OPTION) return;
            ui.currentFile = chooser.getSelectedFile();
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ui.currentFile))) {
            bw.write(ui.textArea.getText());
            ui.setTitle("SimpleNotepad - " + ui.currentFile.getName());
        } catch (IOException ex) {
            showError("Failed to save file: " + ex.getMessage());
        }
    }

    private void doExit() {
        int ans = JOptionPane.showConfirmDialog(ui, "Are you sure you want to exit?", "Exit", JOptionPane.YES_NO_OPTION);
        if (ans == JOptionPane.YES_OPTION) {
            ui.dispose();
            System.exit(0);
        }
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(ui, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}

public class NotepadApp {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            NotepadUI ui = new NotepadUI();
            ui.setVisible(true);
        });
    }
}


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class NotepadUI extends JFrame {

    // Text area and file state
    public JTextArea textArea;
    public File currentFile = null;

    // Menu items
    public JMenuItem newItem, openItem, saveItem, exitItem;
    public JMenuItem cutItem, copyItem, pasteItem;
    public JMenuItem fontItem, colorItem;
    public JMenuItem aboutItem;

    public NotepadUI() {
        super("SimpleNotepad - Untitled");
        initUI();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
    }

    private void initUI() {
        // Text area within scroll pane
        textArea = new JTextArea();
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scroller = new JScrollPane(textArea);
        getContentPane().add(scroller, BorderLayout.CENTER);

        // Menu bar
        JMenuBar menuBar = new JMenuBar();

        // File menu
        JMenu fileMenu = new JMenu("File");
        newItem = new JMenuItem("New");
        openItem = new JMenuItem("Open...");
        saveItem = new JMenuItem("Save");
        exitItem = new JMenuItem("Exit");
        fileMenu.add(newItem);
        fileMenu.add(openItem);
        fileMenu.add(saveItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);

        // Edit menu (Cut/Copy/Paste)
        JMenu editMenu = new JMenu("Edit");
        cutItem = new JMenuItem("Cut");
        copyItem = new JMenuItem("Copy");
        pasteItem = new JMenuItem("Paste");
        editMenu.add(cutItem);
        editMenu.add(copyItem);
        editMenu.add(pasteItem);
        menuBar.add(editMenu);

        // Format menu (optional)
        JMenu formatMenu = new JMenu("Format");
        fontItem = new JMenuItem("Font...");
        colorItem = new JMenuItem("Font Color...");
        formatMenu.add(fontItem);
        formatMenu.add(colorItem);
        menuBar.add(formatMenu);

        // Help menu
        JMenu helpMenu = new JMenu("Help");
        aboutItem = new JMenuItem("About");
        helpMenu.add(aboutItem);
        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        // Wire up actions
        NotepadActions actions = new NotepadActions(this);
        newItem.addActionListener(actions);
        openItem.addActionListener(actions);
        saveItem.addActionListener(actions);
        exitItem.addActionListener(actions);

        cutItem.addActionListener(actions);
        copyItem.addActionListener(actions);
        pasteItem.addActionListener(actions);

        fontItem.addActionListener(actions);
        colorItem.addActionListener(actions);

        aboutItem.addActionListener(actions);
    }

    public static class FontChooserDialog extends JDialog {
        private JComboBox<String> familyBox;
        private JComboBox<String> styleBox;
        private JComboBox<Integer> sizeBox;
        private Font selected = null;

        public FontChooserDialog(Frame owner, Font initial) {
            super(owner, "Choose Font", true);
            setLayout(new BorderLayout());

            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            String[] families = ge.getAvailableFontFamilyNames();

            familyBox = new JComboBox<>(families);
            familyBox.setSelectedItem(initial.getFamily());

            String[] styles = {"Plain", "Bold", "Italic", "Bold Italic"};
            styleBox = new JComboBox<>(styles);
            styleBox.setSelectedIndex(initial.isBold() ? (initial.isItalic() ? 3 : 1) : (initial.isItalic() ? 2 : 0));

            Integer[] sizes = new Integer[50];
            for (int i = 0; i < sizes.length; i++) sizes[i] = 8 + i;
            sizeBox = new JComboBox<>(sizes);
            sizeBox.setSelectedItem(initial.getSize());

            JPanel center = new JPanel(new GridLayout(3, 2, 6, 6));
            center.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
            center.add(new JLabel("Font Family:"));
            center.add(familyBox);
            center.add(new JLabel("Style:"));
            center.add(styleBox);
            center.add(new JLabel("Size:"));
            center.add(sizeBox);
            add(center, BorderLayout.CENTER);

            JPanel buttons = new JPanel();
            JButton ok = new JButton("OK");
            JButton cancel = new JButton("Cancel");
            buttons.add(ok);
            buttons.add(cancel);
            add(buttons, BorderLayout.SOUTH);

            ok.addActionListener(e -> {
                String fam = (String) familyBox.getSelectedItem();
                int style = styleBox.getSelectedIndex();
                int size = (Integer) sizeBox.getSelectedItem();
                int awtStyle = Font.PLAIN;
                if (style == 1) awtStyle = Font.BOLD;
                else if (style == 2) awtStyle = Font.ITALIC;
                else if (style == 3) awtStyle = Font.BOLD | Font.ITALIC;
                selected = new Font(fam, awtStyle, size);
                setVisible(false);
            });

            cancel.addActionListener(e -> {
                selected = null;
                setVisible(false);
            });

            pack();
            setResizable(false);
            setLocationRelativeTo(owner);
        }

        public static Font showDialog(Component parent, Font initial) {
            Frame owner = JOptionPane.getFrameForComponent(parent);
            FontChooserDialog dlg = new FontChooserDialog(owner, initial == null ? new Font("Monospaced", Font.PLAIN, 14) : initial);
            dlg.setVisible(true);
            return dlg.selected;
        }
    }
}

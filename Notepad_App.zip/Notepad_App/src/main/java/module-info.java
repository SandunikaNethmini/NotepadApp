module com.example.notepad_app {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.notepad_app to javafx.fxml;
    exports com.example.notepad_app;
}